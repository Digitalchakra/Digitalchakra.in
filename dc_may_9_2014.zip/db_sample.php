<?php
$con=mysql_connect('localhost','root','password');
$db=mysql_select_db('dc');
?>
