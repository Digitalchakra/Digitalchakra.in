$(document).ready(function() {
	$(".boxes_img").fancybox({
		/*maxWidth	: 800,
		maxHeight	: 600,*/
		fitToView	: false,
		width		: '95%',
		height		: '95%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none',
		//closeBtn	: false,
		type: 'ajax'
	});
});