<?php

class HostingController extends BaseController {
	
	public function index()
	{
		return View::make('hosting');
	}

}
