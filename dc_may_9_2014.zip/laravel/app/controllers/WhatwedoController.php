<?php

class WhatwedoController extends BaseController {

	public function index()
	{
		return View::make('whatwedo');
	}

}
