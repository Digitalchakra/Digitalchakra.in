<?php

class AboutusController extends BaseController {
	
	public function index()
	{
		return View::make('aboutus');
	}

}
