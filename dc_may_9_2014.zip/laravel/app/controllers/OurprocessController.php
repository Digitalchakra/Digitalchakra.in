<?php

class OurprocessController extends BaseController {
	
	public function index()
	{
		return View::make('ourprocess');
	}

}
