<?php
class Projects extends Eloquent{
	protected $table = 'projects';
}