<?php
class Contact extends Eloquent{
	protected $table = 'contact';
}